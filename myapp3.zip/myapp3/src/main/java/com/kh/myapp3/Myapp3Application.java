package com.kh.myapp3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myapp3Application {

	public static void main(String[] args) {
		SpringApplication.run(Myapp3Application.class, args);
	}

}
